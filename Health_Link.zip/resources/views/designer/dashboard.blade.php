@extends('layouts.master')

@section('content')
    <h1>Welcome, Designer!</h1>
    <p>This is the Designer dashboard.</p>
@endsection
