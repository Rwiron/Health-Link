<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <h4 class="mb-4">Invoice for <?php echo e($appointment->patient->name ?? 'N/A'); ?></h4>
        </div>

        <!-- Invoice Details -->
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h6>Hospital Information</h6>
                            <p><strong>Name:</strong> <?php echo e($hospital->name ?? 'N/A'); ?></p>
                            <p><strong>Address:</strong> <?php echo e($hospital->address ?? 'N/A'); ?></p>
                        </div>
                        <div class="col-md-6 text-md-right">
                            <h6>Doctor Information</h6>
                            <p><strong>Name:</strong> <?php echo e($doctor->name ?? 'N/A'); ?></p>
                            <p><strong>Email:</strong> <?php echo e($doctor->email ?? 'N/A'); ?></p>
                        </div>
                    </div>

                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h6>Appointment Details</h6>
                            <p><strong>Date:</strong> <?php echo e($appointment->appointment_date); ?></p>
                            <p><strong>Status:</strong>
                                <?php if($appointment->status == 'confirmed'): ?>
                                <span class="badge bg-success">Confirmed</span>
                                <?php elseif($appointment->status == 'pending'): ?>
                                <span class="badge bg-warning">Pending</span>
                                <?php else: ?>
                                <span class="badge bg-danger">Cancelled</span>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="col-md-6 text-md-right">
                            <h6>Invoice</h6>
                            <p><strong>Invoice Number:</strong> <?php echo e($invoice->id ?? 'N/A'); ?></p>
                            <p><strong>Total Amount:</strong> $<?php echo e($invoice->total_amount ?? '0.00'); ?></p>
                        </div>
                    </div>

                    <!-- Print Button -->
                    <div class="d-flex justify-content-end">
                        <button onclick="window.print()" class="btn btn-primary">Print Invoice</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ProjectProduct\Health_Link\resources\views/doctor/report/invoice.blade.php ENDPATH**/ ?>