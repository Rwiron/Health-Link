/*
Template Name: StarCode & Dashboard Template
Author: StarCode Kh
Website: https://StarCode Kh.in/
Contact: StarCode Kh@gmail.com
File: plugins scroll hint init js
*/

new ScrollHint('.js-scrollable');